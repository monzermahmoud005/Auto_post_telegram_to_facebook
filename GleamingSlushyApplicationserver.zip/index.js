const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const path = require('path');
const express = require('express');

// إعدادات البوت
const BOT_TOKEN = "7530605491:AAEC6josL0ilDcqxP1hOknSNDO1guuqiHk8";
const CHANNEL_ID = "@sudan_news1";
const bot = new TelegramBot(BOT_TOKEN, { polling: false });

// إعداد الواجهة
const app = express();
app.use(express.static('public')); // للمجلد الثابت (مثل الصور)

// متغيرات لتتبع الحالة
let posts = [];
let images = [];
let delay = 60; // الافتراضي:10 دقائق
let status = "Ready";
let errors = [];

// قراءة البيانات من الملفات
function loadPostsAndImages() {
  try {
    const postsContent = fs.readFileSync(path.join(__dirname, 'posts.txt'), 'utf-8');
    posts = postsContent.split('\n').map(post => post.trim()).filter(post => post.length > 0);

    const imagesFolder = path.join(__dirname, 'images');
    images = fs.readdirSync(imagesFolder)
      .filter(file => /\.(jpg|jpeg|png)$/i.test(file))
      .map(file => path.join(imagesFolder, file));

    status = `Loaded ${posts.length} posts and ${images.length} images.`;
  } catch (err) {
    errors.push(`Error loading posts or images: ${err.message}`);
    status = "Error loading posts or images.";
  }
}

// النشر التلقائي
async function schedulePosts() {
  status = "Posting started...";
  let currentPostIndex = 0;

  while (true) {
    try {
      // نشر النصوص
      if (posts.length > 0) {
        const post = posts[currentPostIndex];
        await bot.sendMessage(CHANNEL_ID, post);
        status = `تم نشر النص بنجاح: ${post}`;  // تحديث الحالة مع كل منشور
        updateStatus(); // تحديث واجهة الويب مع كل منشور

        // تأخير بين المنشورات
        currentPostIndex = (currentPostIndex + 1) % posts.length;
      }

      // نشر الصور
      for (const imagePath of images) {
        const imageStream = fs.createReadStream(imagePath);
        await bot.sendPhoto(CHANNEL_ID, imageStream);
        status = `تم نشر الصورة بنجاح: ${path.basename(imagePath)}`;  // تحديث الحالة مع كل صورة
        updateStatus(); // تحديث واجهة الويب مع كل صورة
      }

      // تأخير بين النشر
      await new Promise(resolve => setTimeout(resolve, delay * 1000));
    } catch (err) {
      errors.push(`Error during posting: ${err.message}`);
      status = `Error during posting: ${err.message}`;
      updateStatus(); // تحديث حالة الواجهة عند حدوث خطأ
    }
  }
}

// تحديث حالة الواجهة
function updateStatus() {
  app.get('/', (req, res) => {
    res.send(`
      <html>
        <head>
          <title>Telegram Scheduler</title>
          <style>
            body { font-family: Arial, sans-serif; text-align: center; margin-top: 20px; }
            .status { margin-bottom: 20px; }
            .errors { color: red; }
            .box { border: 1px solid #ddd; padding: 10px; margin: 10px; display: inline-block; }
          </style>
        </head>
        <body>
          <h1>Telegram Scheduler</h1>
          <div class="status">
            <h3>Status:</h3>
            <div class="box">${status}</div>
          </div>
          <div class="errors">
            <h3>Errors:</h3>
            ${errors.length ? errors.map(e => `<div class="box">${e}</div>`).join('') : '<div class="box">No errors.</div>'}
          </div>
        </body>
      </html>
    `);
  });
}

// بدء السيرفر
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});

// بدء النشر
loadPostsAndImages();
schedulePosts();